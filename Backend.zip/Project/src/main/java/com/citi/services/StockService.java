package com.citi.services;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Scanner;

import com.citi.dto.stockDTO;

import yahoofinance.Stock;
import yahoofinance.YahooFinance;
import yahoofinance.histquotes.HistoricalQuote;
import yahoofinance.histquotes.Interval;
import yahoofinance.histquotes2.QueryInterval;
import yahoofinance.query2v8.HistQuotesQuery2V8Request;

public class StockService {
	
	PriorityQueue<stockDTO> stockList = new PriorityQueue<stockDTO>(new ComparatorService());
	
	 public List<String> readNiftyCSV(String user_sector) throws FileNotFoundException{
			List<String> symbolListRet = new ArrayList();
			
			Scanner sc = new Scanner(new File("C:\\Users\\Anandamayee Modak\\Documents\\CitiBridge\\Nifty100.xlsx.csv"));  
			sc.useDelimiter(",");   //sets the delimiter pattern  
			
			while (sc.hasNext())  //returns a boolean value  
			{  
			
			String symbol = sc.next();
			String sector = sc.next();
			
			if(sector.equalsIgnoreCase(user_sector)) {
				symbolListRet.add(symbol);
			}
			}
			//returns list of ticker symbols corresponding to the user selected sector
			return symbolListRet;
		}
	 
	 public PriorityQueue<stockDTO> getStock(List<String> symbolList) throws IOException {
		 	
			List<Double> sScores = new ArrayList();
			List<List<BigDecimal>> closedLists = new ArrayList<List<BigDecimal>>();
			List<List<String>> datesLists = new ArrayList<List<String>>();
		 	List<BigDecimal> epsList = new ArrayList<BigDecimal>();
		 	List<BigDecimal> peList = new ArrayList<BigDecimal>();
			
			for(int i=0; i<symbolList.size();i++) {
			String symbol = symbolList.get(i).concat(".NS");
			symbol = symbol.replace("\n","").replace("\r","");
//			Stock s = YahooFinance.get(symbol);
			Calendar from = Calendar.getInstance();
			Calendar to = Calendar.getInstance();
			from.add(Calendar.DATE, -14);
			
			Stock stock = YahooFinance.get(symbol);
			List<HistoricalQuote>history = stock.getHistory(from, Interval.DAILY);
			List<BigDecimal> closed = new ArrayList<BigDecimal>();
			List<String> dates = new ArrayList<String>();
			
			for(HistoricalQuote quote:history) {
				System.out.println("=================================");
				System.out.println("Symbol: "+ quote.getSymbol());
				System.out.println("Date: "+ convertDate(quote.getDate()));
				System.out.println("High: "+ quote.getHigh());
				System.out.println("Low: "+ quote.getLow());
				System.out.println("Open: "+quote.getOpen());
				System.out.println("Close: "+quote.getClose());
				dates.add(convertDate(quote.getDate()));
				closed.add(quote.getClose().setScale(2,RoundingMode.HALF_UP));
				System.out.println("=================================");
			}
			
			epsList.add(validate(stock.getStats().getEps()));
			peList.add(validate(stock.getStats().getPe()));
			sScores.add(scoreCalculator(symbol,history));
			datesLists.add(dates);
			closedLists.add(closed);
			}
			
			return stockLister(symbolList, sScores, closedLists, datesLists, epsList, peList);

	 }
	 
	 public void getStock(stockDTO stock) throws IOException {
		 
		 List<BigDecimal> closed = new ArrayList<BigDecimal>();
		 List<String> dates = new ArrayList<String>();
		 
		 String reqSymbol = stock.getSymbol().concat(".NS");
		 Calendar from = Calendar.getInstance();
		 Calendar to = Calendar.getInstance();
		 from.add(Calendar.DATE, -14);
		 HistQuotesQuery2V8Request s = new HistQuotesQuery2V8Request(reqSymbol, from, to, QueryInterval.DAILY);
		 List<HistoricalQuote> history = s.getResult();
		 
		 for(HistoricalQuote quote:history) {
//			 stock.getClosed().add(quote.getClose());
//			 stock.getDates().add(convertDate(quote.getDate()));
			 closed.add(quote.getClose().setScale(2, RoundingMode.HALF_UP));
			 dates.add(convertDate(quote.getDate()));
		 }
		 stock.setClosed(closed);
		 stock.setDates(dates);
		 stock.setStock_score(scoreCalculator(reqSymbol, history));
	 }
	 
	 public void getStockCurrent(stockDTO stockObj) throws IOException {
		 Stock stock = YahooFinance.get(stockObj.getSymbol().concat(".NS"));
		 BigDecimal price = stock.getQuote(true).getPrice();
		 BigDecimal eps = stock.getStats().getEps();
		 BigDecimal pe = stock.getStats().getPe();
		 stockObj.setCurrent(price.setScale(2, RoundingMode.HALF_UP));
		 stockObj.setEps(validate(eps).setScale(2, RoundingMode.HALF_UP));
		 stockObj.setPe(validate(pe).setScale(2, RoundingMode.HALF_UP));
	 }
	 
		private String convertDate(Calendar cal) {
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String formatted = sdf.format(cal.getTime());
			return formatted;
		}
		private double scoreCalculator(String symbol, List<HistoricalQuote> hq) {
			
			double avg = 0.0;
			for(int j=0;j<hq.size()-1;j++) {
				avg = avg + ((hq.get(j+1).getClose().doubleValue()-hq.get(j).getClose().doubleValue()));
			}
			avg = avg/hq.size();
			BigDecimal bd = new BigDecimal(avg).setScale(2, RoundingMode.HALF_UP);
			
			return bd.doubleValue();
		}
		
		private PriorityQueue<stockDTO> stockLister(List<String> symbols, List<Double> scores, List<List<BigDecimal>> closedLists, List<List<String>> datesLists, List<BigDecimal> epsList, List<BigDecimal> peList) {
			for(int i=0; i<symbols.size();i++) {
			stockList.add(new stockDTO(symbols.get(i),scores.get(i),closedLists.get(i), datesLists.get(i), epsList.get(i), peList.get(i)));
			}
			return stockList;
			
		}
		
		private BigDecimal validate(BigDecimal bd) {
			if(bd!=null) {
				return bd;
			}
			else {
				return new BigDecimal(0);
			}
		}

}

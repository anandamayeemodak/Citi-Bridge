package com.citi.services;

import java.util.Comparator;

import com.citi.dto.stockDTO;


public class ComparatorService implements Comparator<stockDTO> {
	public int compare(stockDTO s1, stockDTO s2) {
        if (s1.getStock_score() < s2.getStock_score())
            return 1;
        else if (s1.getStock_score() > s2.getStock_score())
            return -1;
                        return 0;
        }
}

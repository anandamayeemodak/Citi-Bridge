package com.citi.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.citi.dto.LoginUser;
import com.citi.dto.Stocks;
import com.citi.dto.User;
import com.citi.dto.stockDTO;
import com.citi.repository.UserRepository;
import com.citi.services.StockService;

@RestController
@CrossOrigin("*")
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserRepository userRepository;
	
	@PostMapping("/addUser")
	public String addUser(@RequestBody User user) {
		List<stockDTO> list=user.getWatchList();
		System.out.println(list);
		list.add(new stockDTO("GOOG"));
		
		 userRepository.save(user);
		 
		 
		 return "Added user successfully :"+user.getUserid();
	}
	
	
	
	
	@PostMapping("/add/{userid}/{stocks}")
	public ResponseEntity<String> addToWatchlist(@PathVariable("userid") String userid, @PathVariable("stocks") String stocks, @RequestBody int quantity) {
		System.out.println("Quantity: " + quantity);
		
		Optional<User> optional=userRepository.findByuserid(userid);
		User user=optional.get();
		List<stockDTO> list=user.getWatchList();
		list.add(new stockDTO(stocks,quantity));
		System.out.println(list);
		
//		list.add(new Stocks("ppp"));
		
		user.setWatchList(list);
		
		userRepository.save(user);
		 return ResponseEntity.ok("Stock added!");
	}
	
	@GetMapping("/delete/{userid}/{stocks}")
	public String deleteFromWatchlist(@PathVariable String userid,@PathVariable String stocks) {
		Optional<User> optional=userRepository.findByuserid(userid);
		User user=optional.get();
		List<stockDTO> list=user.getWatchList();
		System.out.println(list);
		
		for(int i=0; i<list.size();i++) {
			String stockSymbol = list.get(i).getSymbol();
			if(stockSymbol.equals(stocks)) {
				list.remove(i);
				break;
			}
		}
		
		user.setWatchList(list);
		System.out.println("Deleted");
		System.out.println(list);
		
		userRepository.save(user);
		 return "deleted";
	}
	
	
	
	
	@GetMapping("/findAllUsers")
	public List<User> getUsers(){
		return userRepository.findAll();
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping("/getWatchlist/{userid}")
	public ResponseEntity<List<stockDTO>> getWatchlists(@PathVariable("userid") String userid) throws IOException{
		
		Optional<User> optional=userRepository.findByuserid(userid);
		List<stockDTO> watchList = optional.get().getWatchList();
		StockService ss = new StockService();
		
		for(int i=0; i<watchList.size();i++) {
//			watchList.get(i).setStock_score();
			ss.getStock(watchList.get(i));
			ss.getStockCurrent(watchList.get(i));
		}
		
		return ResponseEntity.ok(watchList);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping("/getWatchlists")
	public List<User> getUserWatchlist(){
		List<User> listOfUsers=userRepository.findAll();
		List watchlistsList=new ArrayList<>();
		for(int i=0;i<listOfUsers.size();i++) {
			watchlistsList.add(listOfUsers.get(i).getWatchList());
		}
		return watchlistsList;
	}
	
	@GetMapping("/save/{userid}")
	public  List saveStocks(@PathVariable String userid) {
		Optional<User> optional=getUser(userid);
		User user=optional.get();
//		user.getWatchList().add();
		
		System.out.println(user.getWatchList());
		
		return user.getWatchList();
		
	}
	
	@GetMapping("/{userid}")
	public Optional<User> getUser(@PathVariable("userid") String userid) {
		return userRepository.findByuserid(userid);
	}
	
	
	@GetMapping("/login/{userid}/{password}")
	public String authenticate(@PathVariable("userid") String userid,@PathVariable("password")String password) {
		try {
			Optional<User> optional=getUser(userid);
			
			User user=optional.get();
				
			if(password.equals(user.getPassword())) {
				return "Success";
			}
			else {
				return "Failure";
			}
			
		}
		catch (Exception e) {
			System.out.println(e);
			// TODO: handle exception
		}
			return "Incorrect username";	
	
	}
	
	
	@PostMapping("/login")
	public ResponseEntity<LoginUser> loginUser(@RequestBody LoginUser userData){
		
		System.out.println(userData.getUserid());
		
		Optional<User> user = userRepository.findByuserid(userData.getUserid());
		
		
		if(userData.getPassword().equals(user.get().getPassword())) {
			return ResponseEntity.ok(userData);
		}
		else {
			return (ResponseEntity<LoginUser>) ResponseEntity.internalServerError();
		}
	}
	
}

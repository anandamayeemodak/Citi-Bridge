package com.citi.controller;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.PriorityQueue;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.citi.dto.stockDTO;
import com.citi.services.StockService;


@RestController
@CrossOrigin("*")
@RequestMapping("/sector")
public class SectorController {
	
	@GetMapping("/Finance")
	public ResponseEntity<List<stockDTO>> getFinance() throws Exception {
		
		StockService ss = new StockService();
		List<String> symbolList = ss.readNiftyCSV("Financial Services");
		PriorityQueue<stockDTO> stocks = ss.getStock(symbolList);
		List<stockDTO> stockResp = new ArrayList<>(); 
		
		
		   for(int i=0; i<5;i++) {
	        	stockDTO sdto = stocks.remove();
	        	stockResp.add(sdto);
	        	System.out.println("Symbol: "+sdto.getSymbol());
	        	System.out.println("S-Score: "+ sdto.getStock_score());
	        	System.out.println("Closed prices: "+ sdto.getClosed());
	        	System.out.println("Closing dates: "+ sdto.getDates());
	        }
		
		return ResponseEntity.ok(stockResp);
	}
	
	@GetMapping("/Power")
	public ResponseEntity<List<stockDTO>> getPower() throws Exception {
		
		StockService ss = new StockService();
		List<String> symbolList = ss.readNiftyCSV("Power");
		PriorityQueue<stockDTO> stocks = ss.getStock(symbolList);
		int stockNum = stocks.size();
		List<stockDTO> stockResp = new ArrayList<>(); 
		
		
		   for(int i=0; i<stockNum;i++) {
	        	stockDTO sdto = stocks.remove();
	        	stockResp.add(sdto);
	        	System.out.println("Symbol: "+sdto.getSymbol());
	        	System.out.println("S-Score: "+ sdto.getStock_score());
	        	System.out.println("Closed prices: "+ sdto.getClosed());
	        	System.out.println("Closing dates: "+ sdto.getDates());
	        }
		
		return ResponseEntity.ok(stockResp);
	}
	
	@GetMapping("/Metals & Mining")
	public ResponseEntity<List<stockDTO>> getMnM() throws Exception {
		
		StockService ss = new StockService();
		List<String> symbolList = ss.readNiftyCSV("Metals & Mining");
		PriorityQueue<stockDTO> stocks = ss.getStock(symbolList);
		List<stockDTO> stockResp = new ArrayList<>(); 
		
		
		   for(int i=0; i<5;i++) {
	        	stockDTO sdto = stocks.remove();
	        	stockResp.add(sdto);
	        	System.out.println("Symbol: "+sdto.getSymbol());
	        	System.out.println("S-Score: "+ sdto.getStock_score());
	        	System.out.println("Closed prices: "+ sdto.getClosed());
	        	System.out.println("Closing dates: "+ sdto.getDates());
	        }
		
		return ResponseEntity.ok(stockResp);
	}
	
	@GetMapping("/Construction")
	public ResponseEntity<List<stockDTO>> getConstruction() throws Exception {
		
		StockService ss = new StockService();
		List<String> symbolList = ss.readNiftyCSV("Construction");
		PriorityQueue<stockDTO> stocks = ss.getStock(symbolList);
		int stockNum = stocks.size();
		List<stockDTO> stockResp = new ArrayList<>(); 
		
		
		   for(int i=0; i<stockNum;i++) {
	        	stockDTO sdto = stocks.remove();
	        	stockResp.add(sdto);
	        	System.out.println("Symbol: "+sdto.getSymbol());
	        	System.out.println("S-Score: "+ sdto.getStock_score());
	        	System.out.println("Closed prices: "+ sdto.getClosed());
	        	System.out.println("Closing dates: "+ sdto.getDates());
	        }
		
		return ResponseEntity.ok(stockResp);
	}
	
	@GetMapping("/Healthcare")
	public ResponseEntity<List<stockDTO>> getHealthcare() throws Exception {
		
		StockService ss = new StockService();
		List<String> symbolList = ss.readNiftyCSV("Healthcare");
		PriorityQueue<stockDTO> stocks = ss.getStock(symbolList);
		List<stockDTO> stockResp = new ArrayList<>(); 
		
		
		   for(int i=0; i<5;i++) {
	        	stockDTO sdto = stocks.remove();
	        	stockResp.add(sdto);
	        	System.out.println("Symbol: "+sdto.getSymbol());
	        	System.out.println("S-Score: "+ sdto.getStock_score());
	        	System.out.println("Closed prices: "+ sdto.getClosed());
	        	System.out.println("Closing dates: "+ sdto.getDates());
	        }
		
		return ResponseEntity.ok(stockResp);
	}
	
	@GetMapping("/Consumer Durables")
	public ResponseEntity<List<stockDTO>> getConsumerDurables() throws Exception {
		
		StockService ss = new StockService();
		List<String> symbolList = ss.readNiftyCSV("Consumer Durables");
		PriorityQueue<stockDTO> stocks = ss.getStock(symbolList);
		int stockNum = stocks.size();
		List<stockDTO> stockResp = new ArrayList<>(); 
		
		
		   for(int i=0; i<stockNum;i++) {
	        	stockDTO sdto = stocks.remove();
	        	stockResp.add(sdto);
	        	System.out.println("Symbol: "+sdto.getSymbol());
	        	System.out.println("S-Score: "+ sdto.getStock_score());
	        	System.out.println("Closed prices: "+ sdto.getClosed());
	        	System.out.println("Closing dates: "+ sdto.getDates());
	        }
		
		return ResponseEntity.ok(stockResp);
	}
	
	@GetMapping("/Consumer Services")
	public ResponseEntity<List<stockDTO>> getConsumerServices() throws Exception {
		
		StockService ss = new StockService();
		List<String> symbolList = ss.readNiftyCSV("Consumer Services");
		PriorityQueue<stockDTO> stocks = ss.getStock(symbolList);
		int stockNum = stocks.size();
		List<stockDTO> stockResp = new ArrayList<>(); 
		
		
		   for(int i=0; i<stockNum;i++) {
	        	stockDTO sdto = stocks.remove();
	        	stockResp.add(sdto);
	        	System.out.println("Symbol: "+sdto.getSymbol());
	        	System.out.println("S-Score: "+ sdto.getStock_score());
	        	System.out.println("Closed prices: "+ sdto.getClosed());
	        	System.out.println("Closing dates: "+ sdto.getDates());
	        }
		
		return ResponseEntity.ok(stockResp);
	}
	
	@GetMapping("/Automobile & Auto Components")
	public ResponseEntity<List<stockDTO>> getAACs() throws Exception {
		
		StockService ss = new StockService();
		List<String> symbolList = ss.readNiftyCSV("Automobile and Auto Components");
		PriorityQueue<stockDTO> stocks = ss.getStock(symbolList);
		int stockNum = stocks.size();
		List<stockDTO> stockResp = new ArrayList<>(); 
		
		
		   for(int i=0; i<5;i++) {
	        	stockDTO sdto = stocks.remove();
	        	stockResp.add(sdto);
	        	System.out.println("Symbol: "+sdto.getSymbol());
	        	System.out.println("S-Score: "+ sdto.getStock_score());
	        	System.out.println("Closed prices: "+ sdto.getClosed());
	        	System.out.println("Closing dates: "+ sdto.getDates());
	        }
		
		return ResponseEntity.ok(stockResp);
	}
	
	@GetMapping("/Capital Goods")
	public ResponseEntity<List<stockDTO>> getCapitalGoods() throws Exception {
		
		StockService ss = new StockService();
		List<String> symbolList = ss.readNiftyCSV("Capital Goods");
		PriorityQueue<stockDTO> stocks = ss.getStock(symbolList);
		int stockNum = stocks.size();
		List<stockDTO> stockResp = new ArrayList<>(); 
		
		
		   for(int i=0; i<stockNum;i++) {
	        	stockDTO sdto = stocks.remove();
	        	stockResp.add(sdto);
	        	System.out.println("Symbol: "+sdto.getSymbol());
	        	System.out.println("S-Score: "+ sdto.getStock_score());
	        	System.out.println("Closed prices: "+ sdto.getClosed());
	        	System.out.println("Closing dates: "+ sdto.getDates());
	        }
		
		return ResponseEntity.ok(stockResp);
	}
	
	@GetMapping("/Chemicals")
	public ResponseEntity<List<stockDTO>> getChemicals() throws Exception {
		
		StockService ss = new StockService();
		List<String> symbolList = ss.readNiftyCSV("Chemicals");
		PriorityQueue<stockDTO> stocks = ss.getStock(symbolList);
		int stockNum = stocks.size();
		List<stockDTO> stockResp = new ArrayList<>(); 
		
		
		   for(int i=0; i<stockNum;i++) {
	        	stockDTO sdto = stocks.remove();
	        	stockResp.add(sdto);
	        	System.out.println("Symbol: "+sdto.getSymbol());
	        	System.out.println("S-Score: "+ sdto.getStock_score());
	        	System.out.println("Closed prices: "+ sdto.getClosed());
	        	System.out.println("Closing dates: "+ sdto.getDates());
	        }
		
		return ResponseEntity.ok(stockResp);
	}
	
	@GetMapping("/Consumer Goods")
	public ResponseEntity<List<stockDTO>> getConsumerGoods() throws Exception {
		
		StockService ss = new StockService();
		List<String> symbolList = ss.readNiftyCSV("Fast Moving Consumer Goods");
		PriorityQueue<stockDTO> stocks = ss.getStock(symbolList);
		List<stockDTO> stockResp = new ArrayList<>(); 
		
		
		   for(int i=0; i<5;i++) {
	        	stockDTO sdto = stocks.remove();
	        	stockResp.add(sdto);
	        	System.out.println("Symbol: "+sdto.getSymbol());
	        	System.out.println("S-Score: "+ sdto.getStock_score());
	        	System.out.println("Closed prices: "+ sdto.getClosed());
	        	System.out.println("Closing dates: "+ sdto.getDates());
	        }
		
		return ResponseEntity.ok(stockResp);
	}
	
	@GetMapping("/IT")
	public ResponseEntity<List<stockDTO>> getIT() throws Exception {
		
		StockService ss = new StockService();
		List<String> symbolList = ss.readNiftyCSV("Information Technology");
		PriorityQueue<stockDTO> stocks = ss.getStock(symbolList);
		List<stockDTO> stockResp = new ArrayList<>(); 
		
		
		   for(int i=0; i<5;i++) {
	        	stockDTO sdto = stocks.remove();
	        	stockResp.add(sdto);
	        	System.out.println("Symbol: "+sdto.getSymbol());
	        	System.out.println("S-Score: "+ sdto.getStock_score());
	        	System.out.println("Closed prices: "+ sdto.getClosed());
	        	System.out.println("Closing dates: "+ sdto.getDates());
	        }
		
		return ResponseEntity.ok(stockResp);
	}
	
	@GetMapping("/Realty")
	public ResponseEntity<List<stockDTO>> getRealty() throws Exception {
		
		StockService ss = new StockService();
		List<String> symbolList = ss.readNiftyCSV("Realty");
		PriorityQueue<stockDTO> stocks = ss.getStock(symbolList);
		int stockNum = stocks.size();
		List<stockDTO> stockResp = new ArrayList<>(); 
		
		
		   for(int i=0; i<stockNum;i++) {
	        	stockDTO sdto = stocks.remove();
	        	stockResp.add(sdto);
	        	System.out.println("Symbol: "+sdto.getSymbol());
	        	System.out.println("S-Score: "+ sdto.getStock_score());
	        	System.out.println("Closed prices: "+ sdto.getClosed());
	        	System.out.println("Closing dates: "+ sdto.getDates());
	        }
		
		return ResponseEntity.ok(stockResp);
	}
	
	@GetMapping("/Oil Gas & Fuels")
	public ResponseEntity<List<stockDTO>> getOGCF() throws Exception {
		
		StockService ss = new StockService();
		List<String> symbolList = ss.readNiftyCSV("Oil Gas & Consumable Fuels");
		PriorityQueue<stockDTO> stocks = ss.getStock(symbolList);
		List<stockDTO> stockResp = new ArrayList<>(); 
		
		
		   for(int i=0; i<5;i++) {
	        	stockDTO sdto = stocks.remove();
	        	stockResp.add(sdto);
	        	System.out.println("Symbol: "+sdto.getSymbol());
	        	System.out.println("S-Score: "+ sdto.getStock_score());
	        	System.out.println("Closed prices: "+ sdto.getClosed());
	        	System.out.println("Closing dates: "+ sdto.getDates());
	        }
		
		return ResponseEntity.ok(stockResp);
	}
	
	@GetMapping("/Telecommunication")
	public ResponseEntity<List<stockDTO>> getTelecom() throws Exception {
		
		StockService ss = new StockService();
		List<String> symbolList = ss.readNiftyCSV("Telecommunication");
		PriorityQueue<stockDTO> stocks = ss.getStock(symbolList);
		int stockNum = stocks.size();
		List<stockDTO> stockResp = new ArrayList<>(); 
		
		
		   for(int i=0; i<stockNum;i++) {
	        	stockDTO sdto = stocks.remove();
	        	stockResp.add(sdto);
	        	System.out.println("Symbol: "+sdto.getSymbol());
	        	System.out.println("S-Score: "+ sdto.getStock_score());
	        	System.out.println("Closed prices: "+ sdto.getClosed());
	        	System.out.println("Closing dates: "+ sdto.getDates());
	        }
		
		return ResponseEntity.ok(stockResp);
	}
	
	@GetMapping("/Construction Materials")
	public ResponseEntity<List<stockDTO>> getConstructionMaterials() throws Exception {
		
		StockService ss = new StockService();
		List<String> symbolList = ss.readNiftyCSV("Construction Materials");
		PriorityQueue<stockDTO> stocks = ss.getStock(symbolList);
		int stockNum = stocks.size();
		List<stockDTO> stockResp = new ArrayList<>(); 
		
		
		   for(int i=0; i<stockNum;i++) {
	        	stockDTO sdto = stocks.remove();
	        	stockResp.add(sdto);
	        	System.out.println("Symbol: "+sdto.getSymbol());
	        	System.out.println("S-Score: "+ sdto.getStock_score());
	        	System.out.println("Closed prices: "+ sdto.getClosed());
	        	System.out.println("Closing dates: "+ sdto.getDates());
	        }
		
		return ResponseEntity.ok(stockResp);
	}
	
	@GetMapping("/Services")
	public ResponseEntity<List<stockDTO>> getServices() throws Exception {
		
		StockService ss = new StockService();
		List<String> symbolList = ss.readNiftyCSV("Services");
		PriorityQueue<stockDTO> stocks = ss.getStock(symbolList);
		int stockNum = stocks.size();
		List<stockDTO> stockResp = new ArrayList<>(); 
		
		
		   for(int i=0; i<stockNum;i++) {
	        	stockDTO sdto = stocks.remove();
	        	stockResp.add(sdto);
	        	System.out.println("Symbol: "+sdto.getSymbol());
	        	System.out.println("S-Score: "+ sdto.getStock_score());
	        	System.out.println("Closed prices: "+ sdto.getClosed());
	        	System.out.println("Closing dates: "+ sdto.getDates());
	        }
		
		return ResponseEntity.ok(stockResp);
	}
	
	

}





//System.out.println( "Hello World!" );
//stockDTO dto = new stockDTO();
//StockService ss = new StockService();
//List<String> symbolList = ss.readNiftyCSV("Healthcare");
//PriorityQueue<stockDTO> stocks = ss.getStock(symbolList);
//
//for(int i=0; i<symbolList.size();i++) {
//	stockDTO sdto = stocks.remove();
//	System.out.println("Symbol: "+sdto.getSymbol());
//	System.out.println("S-Score: "+ sdto.getStock_score());
//}
//
//	System.out.println("REQUEST FINISH ");

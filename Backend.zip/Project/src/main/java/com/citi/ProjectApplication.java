package com.citi;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import yahoofinance.Stock;
import yahoofinance.YahooFinance;
import yahoofinance.histquotes.HistoricalQuote;
import yahoofinance.histquotes.Interval;
import yahoofinance.histquotes2.QueryInterval;
import yahoofinance.query2v8.HistQuotesQuery2V8Request;

@SpringBootApplication
public class ProjectApplication {

	public static void main(String[] args) throws IOException {
		SpringApplication.run(ProjectApplication.class, args);
		
//		Calendar from = Calendar.getInstance();
//		Calendar from1 = Calendar.getInstance();
//		Calendar to = Calendar.getInstance();
//		from.add(Calendar.DATE, -14);
//		from1.add(Calendar.DATE, -30);
//		
//		HistQuotesQuery2V8Request s = new HistQuotesQuery2V8Request("WIPRO.NS", from, to, QueryInterval.DAILY);
//		List<HistoricalQuote> history = new ArrayList<HistoricalQuote>();
//		history = s.getResult();
//		
//		for(HistoricalQuote quote:history) {
//			System.out.println("===============================");
//			System.out.println("Symbol: "+ quote.getSymbol());
//			System.out.println("Close: "+quote.getClose());
//			System.out.println("Adj Close: "+quote.getAdjClose());
//			System.out.println("===============================");
//		}
//		
//		Stock stock = YahooFinance.get("WIPRO.NS");
//		BigDecimal price = stock.getQuote(true).getPrice();
//		List<HistoricalQuote>histq = stock.getHistory(from, Interval.DAILY);
//		System.out.println("priceeee"+price);
//		System.out.println("quotessss"+histq);
//		System.out.println("statsssss"+stock.getStats());
		
//		List<String> symbolList = new ArrayList<String>();
//		symbolList.add("WIPRO");
//		symbolList.add("BAJFINANCE");
		
		
//		for(int i=0; i<symbolList.size();i++) {
//			String symbol = symbolList.get(i).concat(".NS");
//			symbol = symbol.replace("\n","").replace("\r","");
//			Stock s = YahooFinance.get(symbol);
//			Calendar from = Calendar.getInstance();
//			Calendar to = Calendar.getInstance();
//			from.add(Calendar.DATE, -14);
//			
//			Stock stock = YahooFinance.get(symbol);
//			List<HistoricalQuote>history = stock.getHistory(from, Interval.DAILY);
//			for(HistoricalQuote quote:history) {
//				System.out.println("=================================");
//				System.out.println("Symbol: "+ quote.getSymbol());
//				System.out.println("High: "+ quote.getHigh());
//				System.out.println("Low: "+ quote.getLow());
//				System.out.println("Open: "+quote.getOpen());
//				System.out.println("Close: "+quote.getClose());
//				System.out.println("=================================");
//			}
//			
//			}
		
		
		
		
	}

}




//List<Double> sScores = new ArrayList();
//List<List<BigDecimal>> closedLists = new ArrayList<List<BigDecimal>>();
//List<List<String>> datesLists = new ArrayList<List<String>>();
//	
//for(int i=0; i<symbolList.size();i++) {
//String symbol = symbolList.get(i).concat(".NS");
//symbol = symbol.replace("\n","").replace("\r","");
////Stock s = YahooFinance.get(symbol);
//Calendar from = Calendar.getInstance();
//Calendar to = Calendar.getInstance();
//from.add(Calendar.DATE, -14);
//
//HistQuotesQuery2V8Request s = new HistQuotesQuery2V8Request(symbol, from, to, QueryInterval.DAILY);
//List<HistoricalQuote> history = s.getResult();
//List<BigDecimal> closed = new ArrayList<BigDecimal>();
//List<String> dates = new ArrayList<String>();
//
//for(HistoricalQuote quote:history) {
//	System.out.println("=================================");
//	System.out.println("Symbol: "+ quote.getSymbol());
//	System.out.println("Date: "+ convertDate(quote.getDate()));
//	System.out.println("High: "+ quote.getHigh());
//	System.out.println("Low: "+ quote.getLow());
//	System.out.println("Open: "+quote.getOpen());
//	System.out.println("Close: "+quote.getClose());
//	dates.add(convertDate(quote.getDate()));
//	closed.add(quote.getClose());
//	System.out.println("=================================");
//}
//
//sScores.add(scoreCalculator(symbol,history));
//datesLists.add(dates);
//closedLists.add(closed);
//}
//
//return stockLister(symbolList, sScores, closedLists, datesLists);

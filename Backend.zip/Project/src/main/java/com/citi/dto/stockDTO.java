package com.citi.dto;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;

import org.springframework.data.mongodb.core.aggregation.ArithmeticOperators.Round;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import yahoofinance.Stock;
import yahoofinance.YahooFinance;
import yahoofinance.histquotes.HistoricalQuote;
import yahoofinance.histquotes.Interval;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class stockDTO {
	
	String symbol;
	double stock_score;
	List<BigDecimal> closed;
	List<String> dates;
	BigDecimal current;
	int quantity = 5;
	BigDecimal eps;
	BigDecimal pe;
	
	public stockDTO(String s){
		symbol = s;
	}
	
	public stockDTO(String s, int q){
		symbol = s;
		quantity = q;
	}
	
	public stockDTO(String s, double ss){
		symbol = s;
		stock_score = ss;
	}
	
	public stockDTO(String s, double ss, List<BigDecimal> c, List<String> d){
		symbol = s;
		stock_score = ss;
		closed = c;
		dates = d;
	}
	
	public stockDTO(String s, double ss, List<BigDecimal> c, List<String> d, BigDecimal e, BigDecimal p){
		symbol = s;
		stock_score = ss;
		closed = c;
		dates = d;
		eps = e.setScale(2,RoundingMode.HALF_UP);
		pe = p.setScale(2, RoundingMode.HALF_UP);
	}
	
}

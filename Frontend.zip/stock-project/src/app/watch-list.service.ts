import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class WatchListService {

  private addToWatchlistUrl = 'http://localhost:9090/user/add'
  private removeFromWatchlistUrl = 'http://localhost:9090/user/delete'
  private getWatchlistUrl = 'http://localhost:9090/user/getWatchlist'

  constructor(private httpClient: HttpClient) { }

  addToWatchList(userid:any, stock:any, quantity:any): Observable<Object>{
    console.log('inside watlchist service '+ userid +' '+stock);
    return this.httpClient.post<any>(`${this.addToWatchlistUrl}/${userid}/${stock}`,quantity);
  }

  removefromWatchList(userid:any, stock:any): Observable<any>{
    return this.httpClient.get<any>(`${this.removeFromWatchlistUrl}/${userid}/${stock}`);
  }

  getWatchList(userid:any): Observable<any>{
    return this.httpClient.get<any>(`${this.getWatchlistUrl}/${userid}`);
  }
}

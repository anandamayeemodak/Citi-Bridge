import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HomeComponent } from '../home/home.component';
import { SectorService } from '../sector.service';
import { Stock } from '../stock';
import { WatchListService } from '../watch-list.service';

import { ChartConfiguration, ChartOptions, ChartType } from "chart.js";

@Component({
  selector: 'app-finance',
  templateUrl: './finance.component.html',
  styleUrls: ['./finance.component.css']
})
export class FinanceComponent implements OnInit  {


  public stocks: any[];
  private response='';
  title = 'ng2-charts-demo';
  
  public lineChartData: ChartConfiguration<'line'>['data'];
  public lineChartData1: ChartConfiguration<'line'>['data'];
  public lineChartData2: ChartConfiguration<'line'>['data'];
  public lineChartData3: ChartConfiguration<'line'>['data'];
  public lineChartData4: ChartConfiguration<'line'>['data'];


  public lineChartOptions: ChartOptions<'line'> = {
    responsive: false
  };
  public lineChartLegend = true;

  constructor(private sectorService: SectorService, private watchListService: WatchListService, private route: ActivatedRoute) { }

  ngOnInit(): void { 
    // console.log(this.sectorService.financeSector());
    this.financeSector()
    
    
  }

  lineCartMethod(){
    this.lineChartData = {
      labels: this.stocks[0].dates,
      datasets: [
        {
          data: this.stocks[0].closed,
          label: this.stocks[0].symbol,
          fill: true,
          tension: 0.1,
          borderColor: 'black',
          borderWidth:1,
          backgroundColor: 'rgba(78, 114, 186,0.7)'
          
        }
      ]
    };

    this.lineChartData1 = {
      labels: this.stocks[1].dates,
      datasets: [
        {
          data: this.stocks[1].closed,
          label: this.stocks[1].symbol,
          fill: true,
          tension: 0.1,
          borderColor: 'black',
          borderWidth:1,
          backgroundColor: 'rgba(56, 122, 176,0.7)'
        }
      ]
    };

    this.lineChartData2 = {
      labels: this.stocks[2].dates,
      datasets: [
        {
          data: this.stocks[2].closed,
          label: this.stocks[2].symbol,
          fill: true,
          tension: 0.1,
          borderColor: 'black',
          borderWidth:1,
          backgroundColor: 'rgba(82, 56, 176,0.7)'
        }
      ]
    };

    this.lineChartData3 = {
      labels: this.stocks[3].dates,
      datasets: [
        {
          data: this.stocks[3].closed,
          label: this.stocks[3].symbol,
          fill: true,
          tension: 0.1,
          borderColor: 'black',
          borderWidth:1,
          backgroundColor: 'rgba(101, 9, 171,0.7)'
        }
      ]
    };

    this.lineChartData4 = {
      labels: this.stocks[4].dates,
      datasets: [
        {
          data: this.stocks[4].closed,
          label: this.stocks[4].symbol,
          fill: true,
          tension: 0.1,
          borderColor: 'black',
          borderWidth:1,
          backgroundColor: 'rgba(84, 95, 255,0.7)'
        }
      ]
    };


  }
 
  financeSector(){
    this.sectorService.financeSector().subscribe(data => {
      this.stocks = data;
      this.lineCartMethod();
      console.log(this.stocks[0].symbol);
    })
  }

  addtoWatchList(stock: any){
    console.log('inside addtoWatchlist method'+stock);
    this.watchListService.addToWatchList(this.route.snapshot.paramMap.get('userid'),stock,0).subscribe(data => {})
    alert(stock+" added to Watchlist successfully!")
  }

  getuserID():any{
    return this.route.snapshot.paramMap.get('userid');
  }


}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { interval, Subscription } from 'rxjs';
import Swal from 'sweetalert2';
import { WatchListService } from '../watch-list.service';

@Component({
  selector: 'app-watch-list',
  templateUrl: './watch-list.component.html',
  styleUrls: ['./watch-list.component.css']
})
export class WatchListComponent implements OnInit {

  private updateSubscription: Subscription;
  public isLoading= true;

  public stocks: any[];

  constructor(private route: ActivatedRoute, private watchListService: WatchListService) { }

  ngOnInit(): void {
    this.getWatchList();
    this.updateSubscription = interval(300000).subscribe(() => {
      this.isLoading = true;
      console.log("refreshing!")
      this.getWatchList();
    })
    
  }

  getuserID():any{
    return this.route.snapshot.paramMap.get('userid');
  }

  getSign(prev:any, curr:any):any{
    if(curr-prev>0){
      return "https://img.icons8.com/ios/30/3F9E2E/up--v1.png"
    }
    else if(curr-prev==0){
      return "https://img.icons8.com/ios/30/DBC625/right--v1.png";
    }
    else{
    return "https://img.icons8.com/ios/30/DB2525/down--v1.png";
    }
  }

  getWatchList(){
    this.watchListService.getWatchList(this.route.snapshot.paramMap.get('userid')).subscribe(watchList =>{
      this.stocks = watchList;
      this.isLoading = false;
      console.log(this.stocks);
    })
  }

  removefromWatchList(stock: any){
    Swal.fire({title: 'Are you sure you want to remove this stock from watchlist?', icon:'warning',showCancelButton: true,confirmButtonText:'Yes, delete it',cancelButtonText:'No, keep it'}).then((result) =>{
      if(result.value){
        this.watchListService.removefromWatchList(this.route.snapshot.paramMap.get('userid'),stock).subscribe(watchList =>{})
        Swal.fire("Stock removed from successfully!","",'info').then(result =>{
          this.ngOnInit();
        })
      }
      else if(result.dismiss === Swal.DismissReason.cancel){
      }
    })
    
     
  }
}

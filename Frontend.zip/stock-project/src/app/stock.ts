export class Stock {
    symbol!: string;
    s_score!:number;
}

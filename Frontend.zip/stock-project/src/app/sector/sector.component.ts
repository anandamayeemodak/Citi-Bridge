import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ChartConfiguration, ChartOptions } from 'chart.js';
import Swal from 'sweetalert2';
import { SectorService } from '../sector.service';
import { WatchListService } from '../watch-list.service';

@Component({
  selector: 'app-sector',
  templateUrl: './sector.component.html',
  styleUrls: ['./sector.component.css']
})
export class SectorComponent implements OnInit {

  public isLoading= true;
  public stocks: any[];
  public quantity: number = 0;
  public quantity0: number = 0;
  public quantity1: number = 0;
  public quantity2: number = 0;
  public quantity3: number = 0;
  public quantity4: number = 0;
  private response='';
  title = 'ng2-charts-demo';
  
  public lineChartData: ChartConfiguration<'line'>['data'];
  public lineChartData1: ChartConfiguration<'line'>['data'];
  public lineChartData2: ChartConfiguration<'line'>['data'];
  public lineChartData3: ChartConfiguration<'line'>['data'];
  public lineChartData4: ChartConfiguration<'line'>['data'];


  public lineChartOptions: ChartOptions<'line'> = {
    responsive: false
  };
  public lineChartLegend = true;


  constructor(private sectorService: SectorService, private watchListService: WatchListService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.getSectorStocks();
    
  }


  lineCartMethod(){
    this.lineChartData = {
      labels: this.stocks[0].dates,
      datasets: [
        {
          data: this.stocks[0].closed,
          label: this.stocks[0].symbol,
          fill: true,
          tension: 0.1,
          borderColor: 'black',
          borderWidth:1,
          backgroundColor: 'rgba(78, 114, 186,0.7)'
          
        }
      ]
    };

    this.lineChartData1 = {
      labels: this.stocks[1].dates,
      datasets: [
        {
          data: this.stocks[1].closed,
          label: this.stocks[1].symbol,
          fill: true,
          tension: 0.1,
          borderColor: 'black',
          borderWidth:1,
          backgroundColor: 'rgba(56, 122, 176,0.7)'
        }
      ]
    };

    this.lineChartData2 = {
      labels: this.stocks[2].dates,
      datasets: [
        {
          data: this.stocks[2].closed,
          label: this.stocks[2].symbol,
          fill: true,
          tension: 0.1,
          borderColor: 'black',
          borderWidth:1,
          backgroundColor: 'rgba(82, 56, 176,0.7)'
        }
      ]
    };

    this.lineChartData3 = {
      labels: this.stocks[3].dates,
      datasets: [
        {
          data: this.stocks[3].closed,
          label: this.stocks[3].symbol,
          fill: true,
          tension: 0.1,
          borderColor: 'black',
          borderWidth:1,
          backgroundColor: 'rgba(101, 9, 171,0.7)'
        }
      ]
    };

    this.lineChartData4 = {
      labels: this.stocks[4].dates,
      datasets: [
        {
          data: this.stocks[4].closed,
          label: this.stocks[4].symbol,
          fill: true,
          tension: 0.1,
          borderColor: 'black',
          borderWidth:1,
          backgroundColor: 'rgba(84, 95, 255,0.7)'
        }
      ]
    };


  }

  addtoWatchList(stock: any, i:any){
    console.log('inside addtoWatchlist method'+stock);
    console.log('index: '+ i)
    
    switch(i){
      case 0:
        console.log(i)
        this.quantity = this.quantity0;
        break;
      
      case 1:
        console.log(i)
        this.quantity = this.quantity1;
        break;

      case 2:
        console.log(i)
        this.quantity = this.quantity2;
        break;

      case 3:
        console.log(i)
        this.quantity = this.quantity3;
        break;
      
      case 4:
        console.log(i)
        this.quantity = this.quantity4;
        break;
    }

    console.log("Quantity: "+this.quantity)
    this.watchListService.addToWatchList(this.route.snapshot.paramMap.get('userid'),stock,this.quantity).subscribe(data => {})
    Swal.fire("Stock added successfully!","",'success')
  }

  getuserID():any{
    return this.route.snapshot.paramMap.get('userid');
  }

  getsectorname():any{
    return this.route.snapshot.paramMap.get('sectorname');
  }

  getSectorStocks(){
    this.sectorService.getSectorStocks(this.route.snapshot.paramMap.get('sectorname')).subscribe(data => {
      this.stocks = data;
      this.isLoading = false;
      this.lineCartMethod();
      console.log(this.stocks[0].symbol);
      console.log(this.route.snapshot.paramMap.get('sectorname'));
      
    })
  }

}

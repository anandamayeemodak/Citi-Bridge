import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { LoginuserService } from '../loginuser.service';
import { User } from '../user';
// import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user:User = new User();

  constructor(private loginuserservice: LoginuserService, private route: Router) { }

  ngOnInit(): void {
  }

  userLogin(): any {
    console.log(this.user)
    this.loginuserservice.loginUser(this.user).subscribe(data => {
      Swal.fire("Login Successful!","",'success').then(result => {
        this.route.navigate(['/home',this.user.userid]);
      })
      return true
    }, error => {
      Swal.fire("Login Failed!","",'error')
      return false
    })
  }

}

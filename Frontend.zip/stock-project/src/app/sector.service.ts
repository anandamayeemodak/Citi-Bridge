import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SectorService {

  private baseUrl = 'http://localhost:9090/sector'

  constructor(private httpClient: HttpClient) { }

  financeSector(): Observable<any>{
    console.log('inside finance sector service'+ this.httpClient.get(`${this.baseUrl}/Finance`));
    return this.httpClient.get<any>(`${this.baseUrl}/Finance`)
  }

  getSectorStocks(sector:any): Observable<any>{
    console.log('inside sector service'+ this.httpClient.get(`${this.baseUrl}/${sector}`));
    return this.httpClient.get<any>(`${this.baseUrl}/${sector}`)
  }
}

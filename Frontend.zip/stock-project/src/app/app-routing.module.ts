import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { FinanceComponent } from './finance/finance.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { SectorComponent } from './sector/sector.component';
import { WatchListComponent } from './watch-list/watch-list.component';

const routes: Routes = [
  {path:'', redirectTo:'login', pathMatch:'full'},
  {path:'login', component: LoginComponent },
  {path: 'home/:userid' , component: HomeComponent},
  {path: 'watchlist/:userid' , component: WatchListComponent},
  {path: 'about/:userid' , component: AboutComponent},
  {path: 'Finance/:userid' , component: FinanceComponent},
  {path: 'sector/:sectorname/:userid' , component: SectorComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

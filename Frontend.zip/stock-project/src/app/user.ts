export class User {
    id!: string;
    userid!: string;
    password!: string;
}
